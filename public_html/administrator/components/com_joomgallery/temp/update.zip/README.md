# JoomRokBox
This plugin integrates RokBox into JoomGallery. Please note that the RokBox system plugin has also to be installed and enabled.
